import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
const Page = () => {
    return (_jsxs("div", { children: [_jsx("h1", { children: "Welcome to the Kiosko App!" }), _jsx("p", { children: "This is a simple landing page. Please login or navigate to the admin panel." })] }));
};
export default Page;
