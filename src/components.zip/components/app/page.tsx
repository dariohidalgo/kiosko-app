import * as React from "react";

const Page = () => {
  return (
    <div>
      <h1>Welcome to the Kiosko App!</h1>
      <p>
        This is a simple landing page. Please login or navigate to the admin
        panel.
      </p>
    </div>
  );
};

export default Page;
